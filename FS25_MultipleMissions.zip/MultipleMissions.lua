MultipleMissions = {}; 
MultipleMissions.metadata = {
	interface = "FS25 ...",
	title = "MultipleMissions",
	notes = "hebt das Missions Limit auf",
	author = "(by HappyLooser)",	
	version = "v0.2 Beta",	
	datum = "25.11.2021",
	update = "12.11.2024",
	web = " no",
	info = " Link Freigabe,Änderungen,Kopien oder Code Benutzung ist ohne meine Zustimmung nicht erlaubt",
	"##Orginal Link Freigabe:"
};

function MultipleMissions:loadMap(name)
	print("---loading ".. tostring(MultipleMissions.metadata.title).. " ".. tostring(MultipleMissions.metadata.version).. " ".. tostring(MultipleMissions.metadata.author).. "---")
	MissionManager.hasFarmReachedMissionLimit = Utils.overwrittenFunction(MissionManager.hasFarmReachedMissionLimit, MissionManager.hasFarmReachedMissionLimit);
end; 

function MissionManager:hasFarmReachedMissionLimit(superFunc, ...)
    return false;
end;
addModEventListener(MultipleMissions);